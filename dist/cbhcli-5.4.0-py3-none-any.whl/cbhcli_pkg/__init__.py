"""
CBHCLI - AI驱动的终端助手 v5.4.0
支持多Agent管理、工具调用和会话管理
"""

__version__ = "5.4.0"
__author__ = "陈丙寰"
__email__ = "13943034070@163.com"
