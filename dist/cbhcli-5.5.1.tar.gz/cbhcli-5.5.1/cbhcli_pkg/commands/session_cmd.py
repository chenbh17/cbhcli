"""会话和上下文命令处理"""
from cbhcli_pkg.core.prompt_utils import ask_text
from cbhcli_pkg.commands.parser import SlashCommand
from cbhcli_pkg.context.compressor import SUMMARY_MARKER


# ===================================================================
#  /resume 历史回显（v5.3.3）
# ===================================================================
# 恢复历史会话后在终端回显历史对话内容（对齐 Web 端"恢复后显示历史消息"）。
# 只展示 user / assistant 消息：工具调用折叠成一行摘要，工具结果不展开
# （完整历史已加载进上下文）；单条消息超长时截断，避免旧的长回复刷屏。
_RESUME_PREVIEW_MSGS = 20       # 最多回显最近多少条消息
_RESUME_PREVIEW_CHARS = 1500    # 单条消息最多回显多少字符


def _term_width(default: int = 80) -> int:
    """终端宽度（限制在合理范围内，避免超宽分隔线）"""
    try:
        import shutil
        return max(40, min(shutil.get_terminal_size((default, 24)).columns, 120))
    except Exception:
        return default


def _render_markdown_block(text: str, prefix: str = "") -> None:
    """用 CLI 的 Markdown 渲染器渲染一段静态文本（复用 AI 回复的渲染效果）"""
    try:
        from cbhcli_pkg.core.markdown_renderer import MarkdownStreamRenderer
        renderer = MarkdownStreamRenderer()
        if prefix:
            renderer.set_prefix(prefix)
        renderer.feed(text if text.endswith("\n") else text + "\n")
        renderer.flush()
    except Exception:
        # 渲染失败时退回纯文本，保证历史内容总能显示
        print(f"{prefix}{text}")


def _print_resumed_history(messages: list, title: str = "") -> None:
    """恢复会话后回显历史对话（v5.3.3）

    Args:
        messages: 会话原始消息列表（含 system/tool，函数内部自行过滤）
        title: 会话标题（可选，用于回显头部）
    """
    from cbhcli_pkg.core.constants import (
        C_RESET, C_DIM, C_SEP, C_USER_BG, C_USER_FG, C_AI_TEXT,
    )

    items = []          # (role, content, tool_calls)
    for msg in messages:
        role = msg.get("role")
        if role not in ("user", "assistant"):
            continue
        content = (msg.get("content") or "").strip()
        tool_calls = msg.get("tool_calls") or []
        if not content and not tool_calls:
            continue
        items.append((role, content, tool_calls))

    if not items:
        return

    shown = items[-_RESUME_PREVIEW_MSGS:]
    omitted = len(items) - len(shown)
    width = _term_width()

    print(f"\n{C_SEP}{'─' * width}{C_RESET}")
    head = "📜 历史会话回显"
    if title:
        head += f" · {title[:60]}"
    head += f"（共 {len(items)} 条消息"
    if omitted > 0:
        head += f"，显示最近 {len(shown)} 条"
    head += "）"
    print(f"{C_DIM}{head}{C_RESET}")
    print(f"{C_SEP}{'─' * width}{C_RESET}")

    for role, content, tool_calls in shown:
        if role == "user":
            text, truncated = content, False
            if len(text) > _RESUME_PREVIEW_CHARS:
                text, truncated = text[:_RESUME_PREVIEW_CHARS], True
            lines = text.split("\n")
            print(f"{C_USER_BG}{C_USER_FG}▌ > {lines[0]}{C_RESET}")
            for line in lines[1:]:
                print(f"{C_USER_BG}{C_USER_FG}    {line}{C_RESET}")
            if truncated:
                print(f"{C_DIM}    …（内容过长，已截断）{C_RESET}")
        else:
            if content:
                text, truncated = content, False
                if len(text) > _RESUME_PREVIEW_CHARS:
                    text, truncated = text[:_RESUME_PREVIEW_CHARS], True
                _render_markdown_block(text, prefix=f"\n{C_AI_TEXT}AI: {C_RESET}")
                if truncated:
                    print(f"{C_DIM}  …（内容过长，已截断）{C_RESET}")
            if tool_calls:
                names = []
                for tc in tool_calls:
                    fn = ((tc.get("function") or {}).get("name")) or "?"
                    names.append(fn)
                uniq = list(dict.fromkeys(names))
                extra = f"，共 {len(names)} 次调用" if len(names) > len(uniq) else ""
                print(f"{C_DIM}   🔧 工具调用: {', '.join(uniq)}{extra}{C_RESET}")
        print()
    print(f"{C_SEP}{'─' * width}{C_RESET}")
    print(f"{C_DIM}（以上为历史回显，完整上下文已恢复，可继续对话）{C_RESET}")



def register_session_commands(parser, app):
    """注册会话相关命令"""
    
    # /reset 或 /new 命令
    def reset_handler(args):
        """重置或创建新会话，自动保存当前会话"""
        if not app.current_agent_name:
            return "❌ 请先选择Agent: /agent switch <name>"
        
        app._reset_session(save_current=True)
        return "✅ 已创建新会话 (上一会话已保存到 history 文件夹)"
    
    parser.register(SlashCommand(
        name="reset",
        description="重置当前会话（自动保存上一会话）",
        usage="",
        handler=reset_handler,
        requires_agent=True
    ))
    
    parser.register(SlashCommand(
        name="new",
        description="创建新会话（自动保存上一会话）",
        usage="",
        handler=reset_handler,
        requires_agent=True
    ))
    
    # /resume 命令 - 恢复历史会话
    def resume_handler(args):
        """列出或恢复历史会话（交互式选择）"""
        if not app.current_agent_name:
            return "❌ 请先选择Agent"

        if not app.session_history:
            return "❌ 会话历史管理器未初始化"

        sessions = app.session_history.list_sessions(50)
        if not sessions:
            return "📭 暂无历史会话"

        # 如果提供了参数，直接用参数选择
        choice = args.strip()

        def _is_group_ref(s: str) -> bool:
            """D1/D2 形式的目录编号（用于排除关键词搜索分支）"""
            return bool(s) and s[0] in "dD" and s[1:].isdigit()

        # 关键词搜索：参数非编号且非已有文件名时，按标题过滤全部历史
        # （历史会话很多时，旧会话超出默认列表窗口，可用关键词找回）
        if choice and not choice.isdigit() and not _is_group_ref(choice) \
                and app.session_history.load_session(choice) is None:
            kw = choice.lower()
            matched = [s for s in app.session_history.list_sessions(500)
                       if kw in (s.get("title") or "").lower()]
            if not matched:
                return f"❌ 未找到标题包含「{choice}」的会话"
            sessions = matched[:50]
            choice = ""  # 展示匹配列表，重新选择

        # ---- v5.3.1+ 第四轮：按工作目录层级分组（会话与目录编号同页显示）----
        import os as _os
        _cwd = _os.getcwd()
        _home = _os.path.expanduser("~")

        def _under_cwd(ws: str) -> bool:
            return bool(ws) and (
                ws == _cwd or ws.startswith(_cwd.rstrip("/") + "/"))

        # 按工作目录分组（组内按最后对话时间倒序）
        _groups = {}
        for s in sessions:
            _groups.setdefault(s.get("workspace") or "", []).append(s)
        for ss in _groups.values():
            ss.sort(key=lambda x: (x.get("updated_at") or x.get("created_at") or ""),
                   reverse=True)

        _group_list = []  # (优先级, 组最新时间, 目录, 会话列表)
        for ws, ss in _groups.items():
            latest = max((x.get("updated_at") or x.get("created_at") or "")
                         for x in ss)
            pri = 2 if not ws else (0 if _under_cwd(ws) else 1)
            _group_list.append((pri, latest, ws, ss))
        # 先按组最新时间倒序，再稳定排序让当前目录组置顶、历史组垫底
        _group_list.sort(key=lambda t: t[1], reverse=True)
        _group_list.sort(key=lambda t: t[0])
        _ordered = [s for _, _, _, ss in _group_list for s in ss]

        if not choice:
            # 无参数时显示交互式层级选择菜单
            lines = ["📋 选择要恢复的会话 (输入会话编号；D+目录编号恢复该目录最新会话):\n"]
            num = 0
            for gi, (pri, latest, ws, ss) in enumerate(_group_list, 1):
                if ws:
                    disp = ws
                    if disp.startswith(_home):
                        disp = "~" + disp[len(_home):]
                    mark = " 📍" if ws == _cwd else ""
                    lines.append(f"  [D{gi}] 📂 {disp}{mark}  ({len(ss)} 个会话)")
                else:
                    lines.append(f"  [D{gi}] 🗂 历史（未记录工作目录）  ({len(ss)} 个会话)")
                for s in ss:
                    num += 1
                    updated = (s.get("updated_at")
                               or s.get("created_at", ""))[:16].replace("T", " ")
                    title = s.get("title", "")[:40]
                    count = s.get("message_count", 0)
                    lines.append(f"      {num:2d}. [{updated}] {title} ({count} 条消息)")
            lines.append(f"\n   0. 取消")
            lines.append("   提示: /resume <关键词> 按标题搜索；D编号恢复目录最新会话；📍=当前目录")
            lines.append("")

            print("\n" + "\n".join(lines))
            choice = ask_text("请选择 [会话编号/D目录编号/文件名]: ").strip()

            if not choice or choice == '0':
                return "已取消"

        # 解析用户选择：D目录编号 → 恢复该目录下最新会话
        if _is_group_ref(choice):
            gi = int(choice[1:]) - 1
            if not (0 <= gi < len(_group_list)):
                return f"❌ 无效的目录编号: {choice}"
            target = _group_list[gi][3][0]  # 组内时间倒序第一条=最新
            filename = target["filename"]
            messages = app.session_history.load_session(filename)
            if messages is None:
                return f"❌ 加载会话失败: {filename}"
        else:
            filename = choice
            messages = app.session_history.load_session(filename)
            if messages is None:
                # 尝试用数字索引查找（按分组展示顺序编号）
                try:
                    idx = int(filename) - 1
                    if 0 <= idx < len(_ordered):
                        filename = _ordered[idx]["filename"]
                        messages = app.session_history.load_session(filename)
                    else:
                        return f"❌ 无效的会话编号: {choice}"
                except ValueError:
                    return f"❌ 找不到会话文件: {filename}"

        if messages is None:
            return f"❌ 加载会话失败: {filename}"
        
        # 保存当前会话到 history
        if app.session and len(app.session.messages) > 1:
            try:
                import os as _os
                ctx_msgs = app.session.get_context_messages()
                app.session_history.save_session(
                    ctx_msgs, app.session.id, workspace=_os.getcwd())
            except Exception:
                pass
        
        # 在当前 session 上原地恢复（不创建新会话）
        # 清空当前消息，只保留首条主系统提示（含最新 skills/tools/memory）。
        # 注意：当前会话自己的"历史对话摘要"不能带进被恢复的会话，故不用
        # session.reset()（它会保留全部 system 消息），只保留 messages[0]（v5.2.3）
        if app.session.messages and app.session.messages[0].role == "system":
            app.session.messages = [app.session.messages[0]]
        else:
            app.session.messages = []
        app.session.tool_call_count = 0

        # 重新加载历史消息：跳过 system 消息（旧主系统提示用新建的），
        # 但保留"历史对话摘要"——摘要是 agent 对早期对话的记忆，
        # 丢弃它会导致恢复压缩过的会话后 agent 失忆（v5.2.3 修复）
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content") or ""
            if role == "system" and not content.startswith(SUMMARY_MARKER):
                continue
            app.session.add_message(
                role=role,
                content=content,
                token_count=app.token_counter.count_tokens(content),
                metadata=msg,
                tool_call_id=msg.get("tool_call_id"),
                tool_calls=msg.get("tool_calls"),
                reasoning_content=msg.get("reasoning_content")
            )
        
        # 统计恢复的消息
        user_count = sum(1 for m in messages if m.get("role") == "user")

        # v5.3.3：恢复后在终端回显历史对话（对齐 Web 端"恢复会话后显示历史消息"）
        try:
            _title = ""
            for _s in _ordered:
                if _s.get("filename") == filename:
                    _title = _s.get("title") or ""
                    break
            _print_resumed_history(messages, title=_title)
        except Exception:
            pass     # 回显失败不影响会话恢复本身

        return f"✅ 已恢复会话（{user_count} 轮对话，{len(messages)} 条消息）"
    
    parser.register(SlashCommand(
        name="resume",
        description="列出或恢复历史会话",
        usage="[编号|文件名|关键词]",
        handler=resume_handler,
        requires_agent=True
    ))
    
    # /history 命令 - 查看历史会话列表（/resume 的别名）
    def history_handler(args):
        """查看历史会话列表"""
        return resume_handler("")
    
    parser.register(SlashCommand(
        name="history",
        description="查看历史会话列表",
        usage="",
        handler=history_handler,
        requires_agent=True
    ))
    
    # /comp 命令 - 手动压缩上下文（支持带指令：/comp 保留迁移方案，丢弃调试过程）
    def compress_handler(args):
        """手动压缩上下文，可携带保留/丢弃指令"""
        if not app.current_agent_name:
            return "❌ 请先选择Agent"

        if app.session is None:
            return "❌ 当前没有活动会话"

        instructions = args.strip()

        # 执行压缩
        success = app._compress_context(instructions=instructions)

        if success:
            if instructions:
                return f"✅ 上下文已压缩（按指令: {instructions}）"
            return "✅ 上下文已压缩"
        else:
            # 区分"压缩失败"和"无需压缩"：last_error 有值说明摘要生成真的失败了
            err = getattr(app.context_compressor, "last_error", None)
            if err:
                return f"❌ 压缩失败: {err}"
            return "ℹ️  上下文较短,无需压缩"

    parser.register(SlashCommand(
        name="comp",
        description="手动压缩上下文（可带指令: /comp 保留X 丢弃Y）",
        usage="[压缩指令]",
        handler=compress_handler,
        requires_agent=True
    ))

    # /undo-compress 命令 - 撤销最近一次上下文压缩
    def undo_compress_handler(args):
        """撤销最近一次上下文压缩（从备份恢复原始消息）"""
        if not app.current_agent_name:
            return "❌ 请先选择Agent"

        if app.session is None:
            return "❌ 当前没有活动会话"

        if not app.context_compressor:
            return "❌ 压缩组件未初始化"

        backups = app.context_compressor.list_backups()
        if not backups:
            return "📭 没有可撤销的压缩记录"

        choice = args.strip()

        if not choice:
            # 无参数时显示交互式选择菜单
            lines = ["📋 选择要恢复的压缩记录 (输入编号):\n"]
            for i, b in enumerate(backups, 1):
                lines.append(
                    f"  {i:2d}. [{b['time']}] "
                    f"{b['before_tokens']:,} → {b['after_tokens']:,} tokens "
                    f"({b['message_count']} 条消息)")
            lines.append(f"\n   0. 取消")
            lines.append("")

            print("\n" + "\n".join(lines))
            choice = ask_text("请选择 [编号]: ").strip()

            if not choice or choice == '0':
                return "已取消"

        # 解析编号并恢复
        try:
            idx = int(choice) - 1
            if not (0 <= idx < len(backups)):
                return f"❌ 无效的编号: {choice}"
        except ValueError:
            return f"❌ 无效的编号: {choice}"

        backup = backups[idx]
        success = app.context_compressor.restore_backup(backup["file"], app.session)

        if not success:
            return "❌ 恢复失败（备份文件可能已损坏）"

        # 更新上下文窗口
        if app.context_window:
            total = app.session.get_total_tokens(app.token_counter)
            app.context_window.update(total)

        return (f"✅ 已恢复压缩前的上下文 "
                f"({backup['after_tokens']:,} → {backup['before_tokens']:,} tokens, "
                f"{backup['time']})")

    parser.register(SlashCommand(
        name="undo-compress",
        description="撤销最近一次上下文压缩（恢复压缩前的原始消息）",
        usage="[编号]",
        handler=undo_compress_handler,
        requires_agent=True
    ))
    
    # /ctx 命令 - 显示上下文使用情况
    def context_handler(args):
        """显示上下文使用情况"""
        if not app.current_agent_name:
            return "❌ 请先选择Agent"

        if app.context_window is None:
            return "❌ 上下文窗口未初始化"

        # 获取模型名称（优先配置名称：同一模型 ID 可配置多份不同参数）
        model_name = "未配置"
        if app.llm_client and hasattr(app.llm_client, 'config_name'):
            model_name = app.llm_client.config_name
        elif app.llm_client and hasattr(app.llm_client, 'model_name'):
            model_name = app.llm_client.model_name
        elif app.current_agent_config and app.current_agent_config.primary_model:
            model_name = app.current_agent_config.primary_model

        # 更新 context_window
        if app.session:
            total_tokens = app.session.get_total_tokens()
            app.context_window.update(total_tokens)

        status = app.context_window.get_status_text()
        remaining = app.context_window.remaining_tokens()

        lines = [
            f"🤖 Agent: {app.current_agent_name}",
            f"📊 模型: {model_name}",
            f"",
            f"📈 {status}",
            f"📝 剩余: {remaining:,} tokens",
        ]

        # 按消息类型统计 token 分布
        if app.session:
            system_tokens = 0
            user_tokens = 0
            assistant_tokens = 0
            tool_tokens = 0
            for msg in app.session.messages:
                if msg.role == "system":
                    system_tokens += msg.token_count
                elif msg.role == "user":
                    user_tokens += msg.token_count
                elif msg.role == "assistant":
                    assistant_tokens += msg.token_count
                elif msg.role == "tool":
                    tool_tokens += msg.token_count

            lines.append("")
            lines.append("📦 Token 分布:")
            lines.append(f"  系统提示:    {system_tokens:>8,} tokens (含 soul/tools/usage/memory/skills)")
            lines.append(f"  tools schema: {app.context_window.tools_schema_tokens:>7,} tokens (OpenAI function calling 定义)")
            lines.append(f"  用户消息:    {user_tokens:>8,} tokens")
            lines.append(f"  AI 回复:     {assistant_tokens:>8,} tokens")
            lines.append(f"  工具结果:    {tool_tokens:>8,} tokens")

        lines.append("")
        lines.append(f"💬 消息数: {len(app.session.messages) if app.session else 0}")
        lines.append(f"🔧 工具调用: {app.session.tool_call_count if app.session else 0}")
        lines.append("")
        lines.append(f"⚙️  自动压缩: {'启用' if app.current_agent_config and app.current_agent_config.auto_compress else '禁用'}")
        lines.append(f"🎯 压缩阈值: {app.context_window.compression_ratio * 100:.0f}%")

        return "\n".join(lines)
    
    parser.register(SlashCommand(
        name="ctx",
        description="显示上下文使用情况",
        usage="",
        handler=context_handler,
        requires_agent=True
    ))
