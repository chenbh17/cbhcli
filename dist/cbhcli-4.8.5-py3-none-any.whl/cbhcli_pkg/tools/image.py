"""图片识别工具 - 调用视觉模型识别图片内容"""
import base64
import mimetypes
from pathlib import Path
from cbhcli_pkg.tools.registry import BaseTool, ToolResult


class ImageTool(BaseTool):
    """图片识别工具

    当主模型不支持视觉功能时，通过此工具调用已配置的视觉模型识别图片内容。
    支持同时识别多张图片，返回视觉模型的识别结果给主模型。
    """

    def __init__(self, app):
        """
        Args:
            app: CBHCLIApp 实例（用于获取全局配置中的视觉模型）
        """
        self._app = app

    @property
    def name(self) -> str:
        return "image"

    @property
    def description(self) -> str:
        return (
            "使用视觉模型识别图片内容并返回识别结果。"
            "当需要分析、识别、描述图片时调用此工具。"
            "支持同时传入多张图片路径。"
            "工具会自动选择已配置的视觉模型进行识别。"
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "image_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "要识别的图片路径列表，支持绝对路径和~路径"
                },
                "prompt": {
                    "type": "string",
                    "description": "对图片的识别需求描述，例如'描述这张图片的内容'或'提取图片中的文字'"
                }
            },
            "required": ["image_paths", "prompt"]
        }

    def execute(self, image_paths: list, prompt: str, **kwargs) -> ToolResult:
        """执行图片识别

        Args:
            image_paths: 图片文件路径列表
            prompt: 识别需求描述

        Returns:
            ToolResult: 视觉模型的识别结果
        """
        if not image_paths:
            return ToolResult(
                success=False,
                output="",
                error="未提供图片路径"
            )

        # 查找已配置的视觉模型
        vision_model_config = self._find_vision_model()
        if not vision_model_config:
            return ToolResult(
                success=False,
                output="",
                error=(
                    "未找到已配置的视觉模型。"
                    "请先使用 /model add 添加一个支持视觉功能的模型"
                    "（添加时选择支持视觉为 y），然后重试。"
                )
            )

        # 加载图片为 base64
        base64_images = []
        loaded_paths = []
        for path in image_paths:
            expanded = Path(path).expanduser()
            if not expanded.exists():
                return ToolResult(
                    success=False,
                    output="",
                    error=f"图片文件不存在: {path}"
                )
            if not expanded.is_file():
                return ToolResult(
                    success=False,
                    output="",
                    error=f"不是文件: {path}"
                )

            # 检测图片类型
            mime_type, _ = mimetypes.guess_type(str(expanded))
            if not mime_type or not mime_type.startswith('image/'):
                return ToolResult(
                    success=False,
                    output="",
                    error=f"不是图片文件: {path}"
                )

            try:
                with open(expanded, 'rb') as f:
                    image_data = f.read()
                    base64_data = base64.b64encode(image_data).decode('utf-8')
                    base64_images.append((base64_data, mime_type))
                    loaded_paths.append(str(expanded))
            except Exception as e:
                return ToolResult(
                    success=False,
                    output="",
                    error=f"加载图片失败 {path}: {str(e)}"
                )

        # 构建视觉模型请求
        try:
            result = self._call_vision_model(
                vision_model_config, base64_images, prompt
            )
        except Exception as e:
            return ToolResult(
                success=False,
                output="",
                error=f"视觉模型调用失败: {str(e)}"
            )

        # 构建输出
        output_lines = [
            f"📷 已使用视觉模型 '{vision_model_config['name']}' 识别 {len(base64_images)} 张图片",
            f"📋 识别需求: {prompt}",
            f"🖼️  图片列表: {', '.join(loaded_paths)}",
            "",
            "--- 识别结果 ---",
            result,
            "--- 结束 ---"
        ]

        # 终端显示精简信息
        display_lines = [
            f"📷 视觉模型 '{vision_model_config['name']}' 识别 {len(base64_images)} 张图片",
            f"📋 识别需求: {prompt}",
        ]

        return ToolResult(
            success=True,
            output="\n".join(output_lines),
            display_output="\n".join(display_lines)
        )

    def _find_vision_model(self):
        """从全局配置中查找支持视觉的模型

        优先使用当前Agent配置的模型（如果它支持视觉），
        否则查找任意一个支持视觉的已配置模型。

        Returns:
            模型配置字典或 None
        """
        from cbhcli_pkg.config.global_config import GlobalConfig
        config = GlobalConfig()
        models = config.get_models()

        if not models:
            return None

        # 优先：当前Agent使用的模型是否支持视觉
        if self._app and self._app.llm_client:
            if getattr(self._app.llm_client, 'supports_vision', False):
                # 当前模型就支持视觉，直接返回其配置
                for m in models:
                    if m.get('name') == self._app.llm_client.model_name:
                        return m
                # 如果找不到配置但支持视觉，直接用当前client
                return {
                    'name': self._app.llm_client.model_name,
                    'apiKey': self._app.llm_client.api_key,
                    'url': self._app.llm_client.base_url,
                    'model': self._app.llm_client.model_name,
                    'vision': True
                }

        # 查找任意支持视觉的模型
        for m in models:
            if m.get('vision', False):
                return m

        return None

    def _call_vision_model(self, model_config: dict, images: list, prompt: str) -> str:
        """调用视觉模型识别图片

        Args:
            model_config: 模型配置字典
            images: [(base64_data, mime_type), ...] 图片列表
            prompt: 识别需求

        Returns:
            视觉模型的文本响应
        """
        from cbhcli_pkg.core.model import LLMClient

        # 创建视觉模型的 LLM 客户端
        client = LLMClient(model_config)

        # 构建多模态消息
        content_parts = [{"type": "text", "text": prompt}]
        for base64_data, mime_type in images:
            content_parts.append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime_type};base64,{base64_data}"}
            })

        messages = [
            {"role": "user", "content": content_parts}
        ]

        # 使用非流式调用获取完整响应
        response = client.chat(messages, temperature=0.1)
        return response